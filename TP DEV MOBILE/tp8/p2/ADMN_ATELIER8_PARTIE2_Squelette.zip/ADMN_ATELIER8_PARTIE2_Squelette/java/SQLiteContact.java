package com.contact;


public class SQLiteContact  {
    
    
       
} 

//String Sql="create table contact (id INTEGER PRIMARY KEY AUTOINCREMENT, nom text NOT  NULL,prenom text not null,numero text not null );";
